#include <iostream>
#include <locale>
#include <string>
#include <vector>
#include <array>
#include <algorithm>
#include "functions.h"
using namespace std;

void insertData(vector<Client*> client) {
	size_t i = 0;
	for (vector<Client*>::iterator it = client.begin(); it != client.end(); it++) {
		(*it)->setNip(generateRandomNip());
		(*it)->setCompanyName("Test" + to_string(i));
		(*it)->setCompanyLocation("Szczecin");
		(*it)->setContractValue((rand() % 100 + 1) * 100);
		(*it)->setContactPersonName("Kontakt" + to_string(i));
		(*it)->setContactPersonSurname("Kontaktowy" + to_string(i));
		(*it)->setContactPersonPhoneNumber(generateRandomPhoneNumber());
		(*it)->setContactPersonMail("test" + to_string(i) + "@test.test");
		i++;
	}
}
void addClient(vector<Client*>& file) {
	setlocale(LC_CTYPE, "Polish");
	array<string, 7> tmpstr;
	int tmpi;
	cout << "NIP: ";
	cin.ignore();
	getline(cin, tmpstr[0]);
	cout << "Nazwa firmy: ";
	getline(cin, tmpstr[1]);
	cout << "Miasto: ";
	getline(cin, tmpstr[2]);
	cout << "Warto�� umowy: ";
	cin >> tmpi;
	cout << "Imi� osoby kontaktowej: ";
	cin >> tmpstr[3];
	cout << "Nazwisko osoby kontaktowej: ";
	cin >> tmpstr[4];
	cout << "Numer telefonu osoby kontaktowej: ";
	cin >> tmpstr[5];
	cout << "Adres email osoby kontaktowej: ";
	cin >> tmpstr[6];
	file.push_back(new Client(tmpstr[0], tmpstr[1], tmpstr[2], tmpi, tmpstr[3], tmpstr[4], tmpstr[5], tmpstr[6]));
}
void printAverageContractValue(vector<Client*> client) {
	setlocale(LC_CTYPE, "Polish");
	if (client.empty()) {
		cout << "Brak klient�w";
		return;
	}
	float avg = 0;
	for (vector<Client*>::iterator it = client.begin(); it != client.end(); it++) {
		avg = avg + (*it)->getContractValue();
	}
	avg = avg / client.size() ;
	cout << "�rednia warto�� umowy wynosi: " << avg << endl;
}
void printContractorWithHighestContractValue(vector<Client*> client) {
	setlocale(LC_CTYPE, "Polish");
	if (client.empty()) {
		cout << "Brak klient�w";
		return;
	}
	size_t max = 0;
	Client* key;
	for (vector<Client*>::iterator it = client.begin(); it != client.end(); it++) {
		if (max < (*it)->getContractValue()) {
			max = (*it)->getContractValue();
			key = *it;
		}
	}
	vector<Client*>::iterator highest = find(client.begin(), client.end(), key);
	cout << "Klient z umow� o najwi�kszej warto�ci: " << (*highest)->getCompanyName() << " : " << (*highest)->getContractValue() << endl;
}
void printContractorWithLowestContractValue(vector<Client*> client) {
	setlocale(LC_CTYPE, "Polish");
	if (client.empty()) {
		cout << "Brak klient�w";
		return;
	}
	size_t min = 1000000;
	Client* key;
	for (vector<Client*>::iterator it = client.begin(); it != client.end(); it++) {
		if (min > (*it)->getContractValue()) {
			min = (*it)->getContractValue();
			key = *it;
		}
	}
	vector<Client*>::iterator lowest = find(client.begin(), client.end(), key);
	cout << "Klient z umow� o najmniejszej warto�ci: " << (*lowest)->getCompanyName() << " : " << (*lowest)->getContractValue() << endl;
}
void addTicket(vector<Client*>& client) {
	setlocale(LC_CTYPE, "Polish");
	if (client.empty()) return;
	size_t index, i = 0;
	bool flag = 0;
	cout << "Podaj numer indeksu klienta, kt�remu chcesz doda� zg�oszenie: ";
	cin >> index;

	vector<Client*>::iterator it = client.begin();
	for (it; it != client.end(); it++) {
		if (index == (*it)->getId()) {
			break;
		}
		if (i + 1 == index) {
			flag = 1;
			break;
		}
		i++;
	}
	if (i >= client.size() || flag == 1) {
		cout << "Nieprawid�owy indeks" << endl;
		return;
	}

	(*it)->addTicket();
}
void deleteTicket(vector<Client*>& client) {
	setlocale(LC_CTYPE, "Polish");
	if (client.empty()) return;
	size_t index, i = 0;
	bool flag = 0;
	cout << "Podaj numer indeksu klienta, kt�remu chcesz usun�� zg�oszenie: ";
	cin >> index;
	vector<Client*>::iterator it = client.begin();
	for (it; it != client.end(); it++) {
		if (index == (*it)->getId()) {
			break;
		}
		if (i + 1 == index) {
			flag = 1;
			break;
		}
		i++;
	}
	if (i >= client.size() || flag == 1) {
		cout << "Nieprawid�owy indeks klienta" << endl;
		return;
	}
	cout << "Podaj numer indeksu zg�oszenia, kt�re chcesz usun��: ";
	cin >> index;
	for (i = 0; i < (*it)->getNumberOfTasks(); i++) {
		if (i + 1 == index) {
			break;
		}
		if (i + 1 == index) {
			flag = 1;
			break;
		}
	}
	if (i >= (*it)->getNumberOfTasks() || flag == 1) {
		cout << "Nieprawid�owy indeks Zg�oszenia" << endl;
		return;
	}
	(*it)->deleteTicket(i);
}
void printTickets(vector<Client*>& client) {
	if (client.empty()) return;
	for (vector<Client*>::iterator it = client.begin(); it != client.end(); it++) {
		cout << "============================================================" << endl;
		cout << (*it)->getCompanyName() << endl;
		(*it)->printTickets();
	}
	cout << "============================================================" << endl;
}
//doesn't work FFS
void printSpecificClientsTickets(vector<Client*>& client) {
	setlocale(LC_CTYPE, "Polish");
	if (client.empty()) return;
	size_t index, i = 0;
	bool flag = 0;
	cout << "Podaj numer indeksu klienta, kt�rego zg�oszenia chcesz wy�wietli�: ";
	cin >> index;

	vector<Client*>::iterator it = client.begin();
	for (it; it != client.end(); it++) {
		if (index == (*it)->getId()) {
			break;
		}
		if (i + 1 == index) {
			flag = 1;
			break;
		}
		i++;
	}
	if (i >= client.size() || flag == 1) {
		cout << "Nieprawid�owy indeks" << endl;
		return;
	}
	cout << (*it)->getCompanyName() << endl;
	(*it)->printTickets();
}

//------------------------------------------------------------------------------------------------------------------------------------------

void create(vector<Employee*>& employee, const size_t size) {
	for (size_t i = 0; i < size; i++) {
		if (rand() % 3 == 0) employee.push_back(new DepartmentManager());
		else employee.push_back(new ServiceTechnician());
	}
}
void insertData(vector<Employee*> employee) {
	setlocale(LC_CTYPE, "Polish");
	for (vector<Employee*>::iterator it = employee.begin(); it != employee.end(); it++) {
		size_t r = rand() % 3 + 1;

		(*it)->setEmployeePesel(generateRandomPESEL());
		(*it)->setEmployeeName("Jan");
		(*it)->setEmployeeSurname("Kowalski");
		if (r == 1) (*it)->setEmployeeDateOfEmployment("25.03.2019");
		else (*it)->setEmployeeDateOfEmployment("25.06.2021");
	}
}
void addEmployee(vector<Employee*>& file) {
	setlocale(LC_CTYPE, "Polish");
	array<string, 5> tmpstr;
	int tmpi;
	cout << "PESEL: ";
	cin >> tmpstr[0];
	cout << "Imi�: ";
	cin >> tmpstr[1];
	cout << "Nazwisko: ";
	cin >> tmpstr[2];
	cout << "Data zatrudnienia: "; //dd.mm.rrrr inaczej si� sypie
	cin >> tmpstr[3];
	cout << "Pozycja: ";
	cin >> tmpstr[4];
	cout << "Sta� pracy: ";
	cin >> tmpi;
	if (tmpstr[4] == "Kierownik" || tmpstr[4] == "kierownik") {
		file.push_back(new DepartmentManager(tmpstr[0], tmpstr[1], tmpstr[2], tmpstr[3], tmpi));
	} else {
		file.push_back(new ServiceTechnician(tmpstr[0], tmpstr[1], tmpstr[2], tmpstr[3], tmpi));
	}
	evaluateEmployee(file, file.size() - 1);
}
void evaluateEmployees(vector<Employee*>& file) {
	if (file.empty()) return;
	for (vector<Employee*>::iterator it = file.begin(); it != file.end(); it++) {
		(*it)->calculateThings();
		(*it)->virtualFunction();
	}
}
void evaluateEmployee(vector<Employee*>& file, size_t index) {
	if (file.empty()) return;
	vector<Employee*>::iterator it = file.begin() + index;
	(*it)->calculateThings();
	(*it)->virtualFunction();
}

//------------------------------------------------------------------------------------------------------------------------------------------

string generateRandomNip() {
	string nip;
	int r;
	for (int i = 0; i < 10; i++) {
		r = rand() % 10;
		nip = nip + to_string(r);
	}
	return nip;
}
string generateRandomPESEL() {
	string nip;
	int r;
	for (int i = 0; i < 11; i++) {
		r = rand() % 10;
		nip = nip + to_string(r);
	}
	return nip;
}
string generateRandomPhoneNumber() {
	string pn;
	int r;
	for (int i = 0; i < 10; i++) {
		r = rand() % 10;
		pn = pn + to_string(r);
	}
	return pn;
}
size_t assignTicketId() {
	static size_t id = 0;
	id++;
	return id;
}
size_t assignClientId() {
	static size_t id = 0;
	id++;
	return id;
}
size_t assignEmployeeId() {
	static size_t id = 0;
	id++;
	return id;
}

void closeTicket(vector<Client*> client, vector<Employee*> employee) {
	if (client.empty() || employee.empty())
		return;
	setlocale(LC_CTYPE, "Polish");
	size_t clientIndex, ticketIndex, employeeIndex, client_i = 0, ticket_i = 0, employee_i = 0;
	bool client_flag = 0, ticket_flag = 0, employee_flag = 0;
	cout << "Podaj indeks firmy, kt�rej zg�oszenie chcesz zamkn��: ";
	cin >> clientIndex;
	cout << "Podaj indeks zg�oszenia, kt�re chcesz zamkn��: ";
	cin >> ticketIndex;
	cout << "Podaj indeks pracownika zamykaj�cego zg�oszenie: ";
	cin >> employeeIndex;

	vector<Client*>::iterator itc = client.begin();
	for (itc; itc != client.end(); itc++) {
		if (clientIndex == (*itc)->getId()) {
			break;
		}
		if (client_i + 1 == clientIndex) {
			client_flag = 1;
			break;
		}
		client_i++;
	}
	if (client_i >= client.size() || client_flag == 1) {
		cout << "Nieprawid�owy indeks klienta" << endl;
		return;
	}

	for (size_t i = 0; i < (*itc)->getNumberOfTasks(); i++) {
		if (i + 1 == ticketIndex) {
			break;
		}
		if (ticket_i + 1 == employeeIndex) {
			ticket_flag = 1;
			break;
		}
		ticket_i = i;
	}
	if (ticket_i >= (*itc)->getNumberOfTasks() || ticket_flag == 1) {
		cout << "Nieprawid�owy indeks Zg�oszenia" << endl;
		return;
	}

	if ((*itc)->getTicketIsClosed(ticket_i) == 1) {
		cout << "Zg�oszenie zamkni�te" << endl;
		return;
	}

	vector<Employee*>::iterator ite = employee.begin();
	for (ite; ite != employee.end(); ite++) {
		if (employeeIndex == (*ite)->getId()) {
			break;
		}
		if (employee_i + 1 == employeeIndex) {
			employee_flag = 1;
			break;
		}
		client_i++;
	}
	if (employee_i >= employee.size() || employee_flag == 1) {
		cout << "Nieprawid�owy indeks pracownika" << endl;
		return;
	}

	string serviceTechnician = (*ite)->getEmployeeName() + " " + (*ite)->getEmployeeSurname();
	(*itc)->changeTicketStatusToClosed(ticket_i, serviceTechnician);
}
